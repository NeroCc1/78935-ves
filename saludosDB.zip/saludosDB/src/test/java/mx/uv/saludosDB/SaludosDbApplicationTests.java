package mx.uv.saludosDB;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SaludosDbApplicationTests {

	@Test
	void contextLoads() {
	}

}
